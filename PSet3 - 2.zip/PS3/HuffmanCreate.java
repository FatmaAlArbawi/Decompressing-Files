/**
 * @Auhtor: Fatma Al Arbawi, CS10, Prof: Tim Pierson
 */

import java.io.*;
import java.util.*;

public class HuffmanCreate implements Huffman {
    private boolean debug = false;

    public void setDebug(boolean debug){
        this.debug = debug;
    }  //setter for debug mode

    @Override
    //Counts frequency of each character in input file and returns map of characters to their frequencies
    public Map<Character, Long> countFrequencies(String pathName) throws IOException {
        Map<Character, Long> frequencyMap = new HashMap<>();  //craete a map to store character frequencies
        for (int i = 0; i < 256; i++) {
            frequencyMap.put((char) i, 0L);  //initialize the map with all the possible characters (0-255)
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(pathName))) {  //read file and count character frequencies
            int c;
            while ((c = reader.read()) != -1) {  //read file character by character till end
                char character = (char) c;
                frequencyMap.put(character, frequencyMap.get(character) + 1);  //increment frequency count of each character
            }
        }                                       //reader gets closed here
        if (debug) {
            System.out.println("Frequency Map: " + frequencyMap);  //print map if debug is true
        }
        return frequencyMap;  //return completed frequency map
    }

    @Override
    public BinaryTree<CodeTreeElement> makeCodeTree(Map<Character, Long> frequencies) {
        PriorityQueue<BinaryTree<CodeTreeElement>> pq;
        pq = new PriorityQueue<>( // // Create a priority queue to store trees, ordered by frequency
                Comparator.comparingLong(a -> a.getData().getFrequency())
        );

        // Iterate through each character and its frequency
        for (Map.Entry<Character, Long> entry : frequencies.entrySet()) {
            // Create a leaf node for each character and add it to the queue
            pq.add(new BinaryTree<>(new CodeTreeElement(entry.getValue(), entry.getKey())));
        }

        // Continue until there's only one tree left in the queue
        while (pq.size() > 1) {
            // Remove the two trees with lowest frequencies
            BinaryTree<CodeTreeElement> left = pq.remove();
            BinaryTree<CodeTreeElement> right = pq.remove();

            // Calculate the combined frequency
            long combinedFrequency = left.getData().getFrequency() + right.getData().getFrequency();

            // Create a new internal node with the combined frequency
            BinaryTree<CodeTreeElement> parent = new BinaryTree<>(new CodeTreeElement(combinedFrequency, null), left, right);

            // Add the new tree back to the queue
            pq.add(parent);
        }

        // Return the root of the final Huffman tree
        return pq.remove();
    }

    @Override
    //Creates Huffman codes for each character using the code tree and returns a map fo the characters to their Huffman codes
    public Map<Character, String> computeCodes(BinaryTree<CodeTreeElement> codeTree) {
        Map<Character, String> codeMap = new HashMap<>();
        computeCodesRecursive(codeTree, "", codeMap);
        if (debug) {
            System.out.println("CodeMap: " + codeMap);
        }
        return codeMap;
    }
    //recursive helper method for computeCodes that traverses tree to generate the codes
    private void computeCodesRecursive(BinaryTree<CodeTreeElement> node, String code, Map<Character, String> codeMap) {
        if (node == null) return;  //base case

        if (node.getData().getChar() != null){  //if it's a leaf node, (has a character)
            codeMap.put(node.getData().getChar(), code);  //add the character to it's code in the map
        }
        else{
            computeCodesRecursive(node.getLeft(), code + "0", codeMap);  //if it's an internal node, recurse left adding '0" to node
            computeCodesRecursive(node.getRight(), code + "1", codeMap); //recurse right adding '1' to the node
        }
    }

    @Override
    //Compresses input file using the generated Huffman codes
    //Writes the compressed data to a new file
    public void compressFile(Map<Character, String> codeMap, String pathName, String compressedPathName) throws IOException {
        BufferedReader reader = null;  //declaring reader and writer ouitside of the try block to us ein finally block
        BufferedBitWriter writer = null;
        try {
            reader = new BufferedReader(new FileReader(pathName));  //open input file for reading
            writer = new BufferedBitWriter(compressedPathName);  //open output file for writing bits

            int c;
            while ((c = reader.read()) != -1) {  //read eahc character from input file
                char character = (char) c;  //Get Huffman code for the character
                String code = codeMap.get(character);
                if (code == null) {  //if no code is found
                    // Handle unknown character
                    System.err.println("Warning: No code found for character: " + character);
                    // Use a default code (e.g., all 1's)
                    code = "11111111";
                }
                for (char bit : code.toCharArray()) {  //for each bit in character's code, write the bit to the output file
                    writer.writeBit(bit == '1');
                }
            }
        } finally {
            if (reader != null) {  //Make sure resources are closed even with exception
                try {
                    reader.close();
                } catch (IOException e) {
                    System.err.println("Error closing reader: " + e.getMessage());
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.err.println("Error closing writer: " + e.getMessage());
                }
            }
        }
    }

    @Override
    //Decompresses the compressed file using the Huffman tree and writes the decompressed data to a new file
    public void decompressFile(String compressedPathName, String decompressedPathName, BinaryTree<CodeTreeElement> codeTree) throws IOException {
        BufferedBitReader reader = null;  //Declare reader and writer outside of block again
        BufferedWriter writer = null;
        try {
            reader = new BufferedBitReader(compressedPathName); //open compressed file for reading bits
            writer = new BufferedWriter(new FileWriter(decompressedPathName));  //open output file for writing decompressed text

            BinaryTree<CodeTreeElement> currentNode = codeTree;  //start at root fo huffman tree
            while (reader.hasNext()) {                              //while there are more bits to read
                boolean bit = reader.readBit();                 //read a bit from a compressed file
                if (bit) {
                    currentNode = currentNode.getRight();       //move left for 0 and right for 1 in Huffman tree
                } else {
                    currentNode = currentNode.getLeft();
                }

                if (currentNode.getData().getChar() != null) {  //if at leaf node
                    writer.write(currentNode.getData().getChar());  //write this char to output file
                    currentNode = codeTree; // Reset to root for next character
                }
            }
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.err.println("Error closing bit reader: " + e.getMessage());
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.err.println("Error closing writer: " + e.getMessage());
                }
            }
        }

        if (debug) {
            System.out.println("File decompressed: " + compressedPathName + " to " + decompressedPathName);
        }
    }

    //Main method tests Huffman code and compresses and decompresses each test file
    public static void main(String[] args) throws IOException {
        HuffmanCreate huffman = new HuffmanCreate();
        huffman.setDebug(true);

        String[] testFiles = {
                "PS3Files/empty.txt",
                "PS3Files/Single_Character.txt",
                "PS3Files/few_chars.txt",
                "PS3Files/small_text.txt",
                "PS3Files/USConstitution.txt",
                "PS3Files/WarAndPeace.txt"
        };

        for (String inputFile : testFiles){
            String compressedFile = inputFile + ".compressed";
            String decompressedFile = inputFile + ".decompressed";

            System.out.println("Processing File: " + inputFile);

            //Count Frequencies
            Map<Character, Long> frequencies = huffman.countFrequencies(inputFile);

            //Make code tree
            BinaryTree<CodeTreeElement> codeTree = huffman.makeCodeTree(frequencies);

            //Compute codes
            Map<Character, String> codeMap = huffman.computeCodes(codeTree);

            //Compress file
            huffman.compressFile(codeMap, inputFile, compressedFile);

            //Decompress file
            huffman.decompressFile(compressedFile, decompressedFile, codeTree);

            System.out.println("Compression and decompression complete for " + inputFile);

            System.out.println("--------------------");
        }
    }

}
